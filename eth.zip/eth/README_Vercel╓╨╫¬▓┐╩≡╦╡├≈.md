# ETH点位系统 Vercel API中转版

这个版本用于让手机只访问 Vercel，不直接访问 Binance。

## 必须这样上传

上传到 Vercel 时，项目根目录必须直接看到这些文件：

```text
index.html
vercel.json
manifest.webmanifest
sw.js
eth-icon.svg
api/klines.js
api/health.js
```

不要把整个 `eth-vercel-api-proxy-deploy` 文件夹作为里面的一层上传。也就是说，Vercel 项目根目录不能是：

```text
eth-vercel-api-proxy-deploy/index.html
```

而必须是：

```text
index.html
```

## 部署后测试

先打开：

```text
https://你的项目.vercel.app/api/health
```

正常应该显示：

```json
{"ok":true}
```

再打开：

```text
https://你的项目.vercel.app/api/klines?interval=15m&limit=50
```

正常应该返回一串K线数组。

最后打开首页：

```text
https://你的项目.vercel.app/
```

## 如果手机还是打不开

1. 确认手机能打开 `/api/health`。
2. 如果 `/api/health` 可以，首页不行，多半是缓存旧页面，清除该网站缓存。
3. 如果 `/api/klines` 不行，看 Vercel Functions 日志。
4. 如果你之前添加过桌面图标，先删除桌面图标，重新访问新网址。
5. Chrome 里打开后刷新两次。

## 当前变化

- 前端不再请求 `api.binance.com`
- 前端不再连接 `stream.binance.com`
- 前端只请求 `/api/klines`
- `/api/klines` 由 Vercel 服务器请求 Binance，失败后尝试 OKX
- HTML 和 API 都设置了 `no-store`，减少手机拿旧缓存
