module.exports = async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  res.status(200).json({
    ok: true,
    service: 'ETH Point System API',
    time: new Date().toISOString()
  });
};
