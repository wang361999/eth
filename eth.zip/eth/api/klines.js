const BINANCE_INTERVALS = new Set(['15m', '1h', '4h', '1d']);
const OKX_INTERVAL_MAP = {
  '15m': '15m',
  '1h': '1H',
  '4h': '4H',
  '1d': '1D'
};

function clampLimit(value) {
  const n = Number.parseInt(value || '500', 10);
  if (!Number.isFinite(n)) return 500;
  return Math.max(50, Math.min(1000, n));
}

async function fetchWithTimeout(url, ms = 3500) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  try {
    const resp = await fetch(url, {
      signal: controller.signal,
      headers: {
        'user-agent': 'ETH-Point-System-Vercel-Proxy/1.0',
        'accept': 'application/json'
      }
    });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    return await resp.json();
  } finally {
    clearTimeout(timer);
  }
}

async function getBinanceKlines(interval, limit) {
  const url = `https://api.binance.com/api/v3/klines?symbol=ETHUSDT&interval=${interval}&limit=${limit}`;
  return await fetchWithTimeout(url);
}

async function getOkxKlines(interval, limit) {
  const bar = OKX_INTERVAL_MAP[interval] || '15m';
  const okxLimit = Math.min(limit, 300);
  const url = `https://www.okx.com/api/v5/market/candles?instId=ETH-USDT&bar=${bar}&limit=${okxLimit}`;
  const json = await fetchWithTimeout(url);
  if (!json || json.code !== '0' || !Array.isArray(json.data)) {
    throw new Error('OKX返回异常');
  }
  return json.data
    .slice()
    .reverse()
    .map(row => {
      const t = Number(row[0]);
      const open = row[1];
      const high = row[2];
      const low = row[3];
      const close = row[4];
      const vol = row[5] || '0';
      return [t, open, high, low, close, vol, t, '0', 0, '0', '0', '0'];
    });
}

module.exports = async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return;
  }

  const interval = BINANCE_INTERVALS.has(req.query.interval) ? req.query.interval : '15m';
  const limit = clampLimit(req.query.limit);

  try {
    const data = await getBinanceKlines(interval, limit);
    res.setHeader('X-Data-Source', 'binance');
    res.status(200).json(data);
  } catch (binanceError) {
    try {
      const data = await getOkxKlines(interval, limit);
      res.setHeader('X-Data-Source', 'okx');
      res.status(200).json(data);
    } catch (okxError) {
      res.status(502).json({
        error: '行情源暂时不可用',
        binance: String(binanceError && binanceError.message || binanceError),
        okx: String(okxError && okxError.message || okxError)
      });
    }
  }
};
